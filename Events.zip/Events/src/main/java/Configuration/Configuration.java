package Configuration;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Events
 * Package =====> Configuration
 * Date    =====> 18 nov. 2019 
 */
public interface Configuration {
	int standardRoomsCONF= 100;
	int suitesCONF= 100;
	int appartsCONF= 100;


}
