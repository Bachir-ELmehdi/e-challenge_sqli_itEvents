package ma.sqli.mitier;

import java.util.Arrays;
import java.util.LinkedList;

import ma.sqli.entite.Personne;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Events
 * Package =====> ma.sqli.mitier
 * Date    =====> 18 nov. 2019 
 */
public class Mitier  implements IMitier{

	public boolean existePersonne(LinkedList<Personne> personnes ,String nom) {
		Personne chekedPersonne = personnes.stream().
			          	  filter(x->x.getNom().equals(nom)).findAny().orElse(null);
		return !(chekedPersonne ==null);
		
	}
//	public boolean existePersonne(LinkedList<Personne> personnes ,String ...noms) {
//		Arrays.stream(noms).forEach(nom->{
//			for(Personne p: personnes) {
//				if(p.getNom().equals(nom))
//					return false;
//			}
//		});
//		return false;
		
//	}

}
