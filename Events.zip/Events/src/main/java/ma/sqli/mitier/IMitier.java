package ma.sqli.mitier;

import java.util.LinkedList;

import ma.sqli.entite.Personne;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Events
 * Package =====> ma.sqli.mitier
 * Date    =====> 18 nov. 2019 
 */
public interface IMitier {
	public boolean existePersonne(LinkedList<Personne> personnes ,String nom);

}
