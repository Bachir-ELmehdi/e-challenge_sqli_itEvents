package ma.sqli.entite;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Events
 * Package =====> ma.sqli.entite
 * Date    =====> 18 nov. 2019 
 */
public class Personne {
	private String nom;
	private String Role;
	
	public Personne(String role,String nom) {
		this.nom = nom;
		this.Role = role;
	}
	
	//--------------les geters et seters -------------///

	public String getNom() {
		return nom;
	}
	

	public void setNom(String nom) {
		this.nom = nom;
	}
	
	/**
	 * @return the role
	 */
	public String getRole() {
		return Role;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		Role = role;
	}

}
