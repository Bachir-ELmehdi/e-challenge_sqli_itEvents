package ma.sqli.entite;

import java.util.LinkedList;

import Factory.FactoryPersonne;
import ma.sqli.mitier.Mitier;
import ma.sqli.mitier.Mitier.*;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Events
 * Package =====> ma.sqli.entite
 * Date    =====> 18 nov. 2019 
 */
public class Hotel {
	 private int standardRooms ;
	 private  int suites ;
	 private int apparts ;
	 private int nombreSpekers;
	 private int nombreStaff;
	 private int nombreConfDeepDive;
	 private int nombreTringa;
	 private int nombreAppart;
	 private Mitier mitier;
	 private LinkedList<Personne> attendes = new LinkedList<Personne>();
	 private LinkedList<Personne> speakers = new LinkedList<Personne>();
	 private FactoryPersonne factp =new FactoryPersonne();
	 
	 public Hotel(int standar,int suites , int apparts) {
		 this.standardRooms = standar;
		 this.suites = suites;
		 this.apparts = apparts;
		 mitier = new Mitier();	 }
	 public Hotel() {
		 
	 }
	 
	 public boolean addAttedes(String role, String nom) {
		 //str.substring(0, 6); // -> Maison

		 boolean test1 = mitier.existePersonne(attendes, nom);		            
		 boolean test2 = mitier.existePersonne(speakers, nom);
		 if(role.equals("SPEAKER") ) 
		         { if(test2 == false)
			        speakers.add(factp.getInstance(role, nom)); 
		            nombreSpekers += 1; 
		            return true;}
		 else if(test1 == false) {
			     
				 if(role.equals("TRINGA")) {
					 if(nombreTringa >=10  && ((nom.substring(0,4)).equals("Name") )==false) {
			    	 nombreAppart +=1;  }
					 else
					 nombreTringa += 1;
				 }
				 if(role.equals("STAFF"))nombreStaff += 1;
				 if(role.equals("CONF") || role.equals("DEEP DIVE"))nombreConfDeepDive =1; 		
				  attendes.add(factp.getInstance(role, nom));		
				  return true;
		         }
		 return false;
	 }
	 public String checkAvailibility() {
            refrechHotel();
		    return "Standard rooms: "+getStandardRooms()+"|Suites: "+getSuites()+"|Aparts: "+getApparts();
	 }
	 
	 public void refrechHotel() {
		 if(nombreTringa >=10){
			 standardRooms -=(nombreTringa);
			 apparts -=nombreAppart;
		 }
		 else {
		 if(standardRooms <= 2)
		 { this.apparts = apparts - (nombreTringa +nombreConfDeepDive +nombreStaff);}
		 else
		     {this.standardRooms = standardRooms - (nombreTringa +nombreConfDeepDive +nombreStaff);}}
		 this.suites = suites - nombreSpekers;
		initialiser();
	 }
	 
	 public void initialiser() {
		 nombreConfDeepDive=0;
		 nombreSpekers =0;
		 nombreStaff = 0;
		 nombreTringa = 0;
	 }
	 
	 public void refrechRoomtStandar() {
		 this.standardRooms = standardRooms - (nombreTringa +nombreConfDeepDive +nombreStaff);
	 }
	 
	 public String  getRoomFor(String nom) {
		 int test = nombreTringa +nombreConfDeepDive +nombreStaff ;
	
		 StringBuilder sb = new StringBuilder();
		 for (Personne p :attendes) {
			 if(p.getNom().equals(nom))
			     {   if(p.getRole().equals("TRINGA") || p.getRole().equals("STAFF"))
						      {   
		    	                if(test >= 10)   sb.append("Apart N°"+(attendes.indexOf(p)+(201-(attendes.size()-nombreAppart))));
		                        else sb.append("Standard room N°"+(attendes.indexOf(p)+1));}
		                         
							    if(p.getRole().equals("CONF")) {
							        	sb.append("Standard room N°"+(attendes.indexOf(p)+1));}
							       
						        if(p.getRole().equals("DEEP DIVE")) {
						        	sb.append("Standard room N°"+(attendes.indexOf(p)));}
						        
			      }
			 }
			 for(Personne p : this.speakers) {
			     if(p.getRole().equals("SPEAKER"))
				       sb.append("Suite N°"+(speakers.indexOf(p)+101));
				
				 }
		 
		 return sb.toString();
	 }
	 
	 
	 
	 
	 /////////////---les geters et les seters ------///////////////
	 
	 /**
	 * @return the apparts
	 */
	public int getApparts() {
		return apparts;
	}
	/**
	 * @return the standardRooms
	 */
	public int getStandardRooms() {
		return standardRooms;
	}
	
	/**
	 * @return the suites
	 */
	public int getSuites() {
		return suites;
	}
	
	/**
	 * @param apparts the apparts to set
	 */
	public void setApparts(int apparts) {
		this.apparts = apparts;
	}
	
	/**
	 * @param standardRooms the standardRooms to set
	 */
	public void setStandardRooms(int standardRooms) {
		this.standardRooms = standardRooms;
	}
	
	/**
	 * @param suites the suites to set
	 */
	public void setSuites(int suites) {
		this.suites = suites;
	}
	 
	/**
	 * @return the nombreAppart
	 */
	public int getNombreAppart() {
		return nombreAppart;
	}
	

}
