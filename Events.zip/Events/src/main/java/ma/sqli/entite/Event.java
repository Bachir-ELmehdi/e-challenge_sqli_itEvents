package ma.sqli.entite;

import java.util.Arrays;
import java.util.LinkedList;

import Factory.FactoryPersonne;
import ma.sqli.mitier.Mitier;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Events
 * Package =====> ma.sqli.entite
 * Date    =====> 18 nov. 2019 
 */
public class Event {
	private Hotel hotel;
	private LinkedList<Personne>register;
    private Mitier mitier = new Mitier();
    FactoryPersonne factp = new FactoryPersonne();
	
	public Event( Hotel hotel) {
		this.hotel = hotel;
		register  = new LinkedList<Personne>();
	}
	public Event() {
	}
	
	public boolean register(String role,String nom) {
		boolean test = mitier.existePersonne(register, nom);
		if(! test) 
		{register.add(factp.getInstance(role, nom));
		                     hotel.addAttedes(role,nom); 
		                         }
		return (!test);
	}
	
	public boolean register(String role,String ...noms) {
		for(String nom: noms) {
			if(mitier.existePersonne(register, nom))
				return false;
		}
		Arrays.stream(noms).
		forEach(nom->{ 
				if( ! mitier.existePersonne(register, nom)) 
				{   
					register.add(factp.getInstance(role, nom));
				 hotel.addAttedes( role, nom);                          
				                     }
		});
		
		return  true;
	}
	
//	public void gereRooms(String offre) {
//		if(offre.equals("TRINGA") || (offre.equals("CONF")  && offre.equals("DEEP DIVE")))
//			{if(hotel.getStandardRooms() ==0)
//				this.hotel.setApparts(this.hotel.getApparts()-1);
//		else
//		     	this.hotel.setStandardRooms(this.hotel.getStandardRooms()-1);}
//		if(offre.equals("STAFF")) this.hotel.setSuites(this.hotel.getSuites()-1);
//
//	}

}
