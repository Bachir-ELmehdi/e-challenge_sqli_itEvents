package Factory;

import ma.sqli.entite.Personne;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Events
 * Package =====> Factory
 * Date    =====> 18 nov. 2019 
 */
public class FactoryPersonne {
	public  Personne getInstance( String role, String nom ) {
		return new Personne(role,nom );
	}

}
